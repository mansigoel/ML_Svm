# ML_Svm
AS part of Machine Learning Assignment 3, we have to analyse MNIST dataset using SVM
